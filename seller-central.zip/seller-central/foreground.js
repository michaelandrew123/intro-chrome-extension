function yourSellerOrder(){ 
 
    var dataSrc = document.querySelector('.a-size-base > span').innerText;
    var list = document.querySelector('.a-row > .a-span12').lastChild.innerHTML;
    var res = list.split("<span>"); 
    var res1 = res[3].split('<span data-test-id="your-seller-order-text">');
    var res2 = res1[1].split('</span>');
     

    var nodeSpanParent = document.createElement("span");
    nodeSpanParent.setAttribute("class", "a-button a-button-primary custom-button-css");
    var nodeSpanChild = document.createElement("span");
    nodeSpanChild.setAttribute("class", "a-button-inner");
    // var nodeSpanSpace = document.createElement("span");
    // nodeSpanSpace.createTextNode("&nbsp;")

    var node = document.createElement("a");                 // Create a <li> node
    node.setAttribute("class", "a-button-text") 
    node.setAttribute("target", "_blank")
    var textnode = document.createTextNode("Amazon.com PO");         // Create a text node
    

    nodeSpanParent.appendChild(nodeSpanChild);
    nodeSpanChild.appendChild(node);
    node.appendChild(textnode);  

    node.setAttribute("href", "https://www.amazon.com/gp/your-account/order-details/?orderID="+res2[0])
    document.querySelector('.a-row > .a-span12').appendChild(nodeSpanParent); 



// var locate = document.querySelector('.a-row > .a-span12').innerHTML;
// console.log(locate);
// var dix = document.querySelector("div.a-spacing-mini > a-column:nth-child(1) > span:nth-last-child(1) > span:nth-last-child(1) > span").innerHTML;
// console.log(dix);

}

if(window.location.host=="sellercentral.amazon.ca"){ 
    yourSellerOrder();
}