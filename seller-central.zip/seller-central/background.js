
let active_tab_id = 0;

chrome.tabs.onUpdated.addListener(tab => {

    chrome.tabs.executeScript(tab.ib, {
        file: './foreground.js'
    });

    chrome.tabs.executeScript(tab.ib, { 
        file: './order-details.js'
    });
    
    chrome.tabs.insertCSS(null, {
        file: './myStyle.css'
    })
    
}); 

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => { 
   // console.log("Chrome Run Time");
});