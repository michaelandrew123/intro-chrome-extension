function orderDetails(){

    //console.log("Hello from order Id");
 
    // var trackId = document.querySelector('div.a-section > div.a-box-group > div.a-box > div.a-box-inner > div.a-row > div > div.a-column > span').innerHTML;
    var trackId = document.querySelector('div.a-box-inner > .a-row:nth-child(2) > div:nth-child(2) > div.a-column:nth-child(2) > span').innerText;
   // a-button a-button-span12 a-button-primary 
    var odNodeSpanParent = document.createElement("span");
    odNodeSpanParent.setAttribute('class', 'a-button a-button-primary custom-button-css');
    var odNodeSpanChild = document.createElement("span");
    odNodeSpanChild.setAttribute('class', 'a-button-inner');
    //class="a-button-text" class="a-button-inner"
    var odNode = document.createElement("a"); 
    
    odNode.setAttribute('class', 'a-button-text');
    odNode.setAttribute('target', '_blank'); 
    var textnode = document.createTextNode("Track Package");         // Create a text node
    odNode.appendChild(textnode); 
    odNodeSpanParent.appendChild(odNodeSpanChild);
    odNodeSpanChild.appendChild(odNode);
    odNode.setAttribute("href", "https://parcelsapp.com/en/tracking/"+trackId)
    document.querySelector('div.a-box-inner > .a-row:nth-child(2) > div:nth-child(2) > div.a-column:nth-child(2)').appendChild(odNodeSpanParent); 
    
    // var string = ""; 
    // var searchLink = "Access-Control-Allow-Origin:https://track24.net/service/pb/tracking/PBXSA005637711/";
    // fetch(searchLink, {
    //     mode: 'cors',
    //     credentials: 'include'
    //   }).then(
    //     res => res.json()
    // ).then(data => console.log(data))
    // .catch(() => console.log("Can’t access " + searchLink + " response. Blocked by browser?"))
        // result => result.blob()
        // ).then(blob => blob.text()
        // ).then(text => console.log(text)
        // ).catch(e => console.error(e)
        // ); 
}

function tracking(){ 
    var track = document.querySelector(".trackingInfoRow:nth-last-child(1) > .trackingInfoDetails > .operationAttribute").innerText;
 //   console.log('This is track page: '+track); 
}
 
if(window.location.host=="sellercentral.amazon.ca"){ 
    orderDetails(); 
}else if(window.location.host == 'track24.net'){ 
    tracking();
}

